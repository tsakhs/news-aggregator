from flask import Flask, jsonify, request
from flask_pymongo import PyMongo
import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
import logging
from bson import ObjectId
from flask_cors import CORS


# pip install Flask Flask-PyMongo requests beautifulsoup4 pandas lxml Flask-PyMongo flask-cors

app = Flask(__name__)
CORS(app)

# Configuration for MongoDB
app.config["MONGO_URI"] = "mongodb+srv://kashifshah5898:WM0affHQ035xW5Al@cluster0.9siu3ix.mongodb.net/naftemporikiDB?retryWrites=true&w=majority"
mongo = PyMongo(app)

@app.before_request
def init_db():
    try:
        # Test the database connection
        mongo.db.news.find_one()
        print("Connected to MongoDB successfully.")
    except Exception as e:
        print(f"Error connecting to MongoDB: {e}")

# http://localhost:5000/scrape?start=1&end=3
@app.route('/scrape', methods=['GET'])
def scrape_data():
    # Get start and end from query parameters
    start = int(request.args.get('start', 1))
    end = int(request.args.get('end', 2))
    
    url_template = "https://www.naftemporiki.gr/newsroom/page/{page}"
    data = {
        "title": [],
        "date": [],
        "category": [],
        "url": [],
        "images": [],
        "summary": [],
        "maintext": [],
        "tags": [],
        "htmlData": [],
    }

    try:
        # Scrape data from the specified range of pages
        for i in range(start, end):
            url = url_template.format(page=i)
            r = requests.get(url)
            soup = BeautifulSoup(r.text, "html.parser")

            # Extract data
            titles = soup.findAll("h3", class_="item-title")
            for t in titles:
                news_url = t.find("a").get("href")
                data["url"].append(news_url)
                data["title"].append(t.find("a").text)

                # Get additional details from the news page
                req = requests.get(news_url)
                soup1 = BeautifulSoup(req.text, "html.parser")
                
                summary1 = soup1.find("div", class_="entry-summary")
                if summary1:
                    p_tag = summary1.find("p")
                    summary = p_tag.text if p_tag else None
                else:
                    summary = None
                data["summary"].append(summary)

                mainText = soup1.find("div", class_="post-content").findAll(["p", "h2", "ul"])
                data["maintext"].append(" ".join([mt.text for mt in mainText]))

                tags = soup1.findAll("a", class_="badge badge-primary btn")
                listTags = [tag.text for tag in tags] if tags else None
                data["tags"].append(listTags)

                # Add HTML content
                data["htmlData"].append(str(soup1))

            categories = soup.findAll("span", class_="category fw-bold text-primary")
            data["category"].extend([c.text for c in categories])

            times = soup.findAll("time", class_="item-published")
            data["date"].extend([t.text for t in times])

            imgs = soup.findAll("img", class_="attachment-medium size-medium")
            for j, img in enumerate(imgs):
                if j % 2 == 0:
                    data["images"].append(img["src"])

        # Insert data into MongoDB with uniqueness check
        for idx in range(len(data["title"])):
            news_item = {
                "title": data["title"][idx],
                "date": data["date"][idx],
                "category": data["category"][idx],
                "url": data["url"][idx],
                "images": data["images"][idx],
                "summary": data["summary"][idx],
                "maintext": data["maintext"][idx],
                "tags": data["tags"][idx],
                # "htmlData": data["htmlData"][idx],
                "link": "https://www.naftemporiki.gr"                
            }

            # Check if the news item already exists in the database
            if not mongo.db.news.find_one({"title": news_item["title"]}):
                mongo.db.news.insert_one(news_item)

        return jsonify({"message": "Data scraped and stored in MongoDB"}), 200

    except Exception as e:
        logging.error(f"Error during scraping: {e}")
        return jsonify({"error": "An error occurred during scraping"}), 500


# http://localhost:5000/news?date=2024-06-18&category=Politics
@app.route('/news', methods=['GET'])
def get_news():
    try:
        # Get date and category from query parameters
        date = request.args.get('date')
        category = request.args.get('category')

        # Build the query filter
        query_filter = {}
        if date:
            query_filter["date"] = date
        if category:
            query_filter["category"] = category

        # Query the database with filter and sort by date in descending order
        news_data = mongo.db.news.find(query_filter).sort("date", -1)

        output = []
        for news in news_data:
            output.append({
                "_id": str(news["_id"]),
                "title": news["title"],
                "date": news["date"],
                "category": news["category"],
                "url": news["url"],
                "images": news["images"],
                "summary": news["summary"],
                "maintext": news["maintext"],
                "tags": news["tags"],
                "link": news["link"],
                # "htmlData": news["htmlData"]
            })
        return jsonify({"data":output,"success":"true"}), 200

    except Exception as e:
        logging.error(f"Error fetching news: {e}")
        return jsonify({"success":"false","error": "An error occurred while fetching news"}), 500


# http://localhost:5000/news
# body: {
#     "title": "New Article",
#     "date": "2024-06-18",
#     "category": "Technology",
#     "url": "https://example.com/new-article",
#     "images": "https://example.com/image.jpg",
#     "summary": "This is a summary of the new article.",
#     "maintext": "This is the main text of the new article.",
#     "tags": ["tag1", "tag2"]
# }

@app.route('/news', methods=['POST'])
def create_news():
    try:
        news_data = request.get_json()
        if not news_data:
            return jsonify({"error": "No data provided"}), 400
        # Basic validation
        required_fields = ["title", "date", "category", "url", "images", "summary", "maintext", "tags"]
        if not all(field in news_data for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400

        mongo.db.news.insert_one(news_data)
        return jsonify({"message": "News item created successfully"}), 201

    except Exception as e:
        logging.error(f"Error creating news: {e}")
        return jsonify({"error": "An error occurred while creating news"}), 500

# http://localhost:5000/news/news_id
# body: {
#     "title": "New Article",
#     "date": "2024-06-18",
#     "category": "Technology",
#     "url": "https://example.com/new-article",
#     "images": "https://example.com/image.jpg",
#     "summary": "This is a summary of the new article.",
#     "maintext": "This is the main text of the new article.",
#     "tags": ["tag1", "tag2"]
# }
@app.route('/news/<news_id>', methods=['PUT'])
def update_news(news_id):
    try:
        news_data = request.get_json()
        if not news_data:
            return jsonify({"error": "No data provided"}), 400
        
        mongo.db.news.update_one({'_id': ObjectId(news_id)}, {'$set': news_data})
        return jsonify({"message": "News item updated successfully"}), 200

    except Exception as e:
        logging.error(f"Error updating news: {e}")
        return jsonify({"error": "An error occurred while updating news"}), 500


# http://localhost:5000/news/news_id
@app.route('/news/<news_id>', methods=['DELETE'])
def delete_news(news_id):
    try:
        mongo.db.news.delete_one({'_id': ObjectId(news_id)})
        return jsonify({"message": "News item deleted successfully"}), 200

    except Exception as e:
        logging.error(f"Error deleting news: {e}")
        return jsonify({"error": "An error occurred while deleting news"}), 500

# For Kathimerini
# http://localhost:5000/scrape_kathimerini?start=1&end=3
@app.route('/scrape_kathimerini', methods=['GET'])
def scrape_kathimerini():
    try:
        # Get start and end from query parameters
        start = int(request.args.get('start', 1))
        end = int(request.args.get('end', 2))

        url_template = "https://www.kathimerini.gr/epikairothta/page/{page}"
        data = {
            "title": [],
            "date": [],
            "category": [],
            "url": [],
            "images": [],
            "summary": [],
            "maintext": [],
            "tags": []
        }

        # Scrape data from the specified range of pages
        for i in range(start, end):
            url = url_template.format(page=i)
            r = requests.get(url)
            soup = BeautifulSoup(r.text, "lxml")

            # Extract data
            time = soup.findAll("time")
            for t in time:
                data["date"].append(t.text)

            titles = soup.findAll("span", class_="card-title")
            for title in titles:
                data["title"].append(title.text)

            urls = soup.findAll("a", class_="py-4 mainlink")
            for url in urls:
                data["url"].append(url.get("href"))

            # Get additional details from the news detail page
            for news_url in data["url"]:
                req = requests.get(news_url)
                new_soup = BeautifulSoup(req.text, "lxml")

                summary = new_soup.find("div", class_="nx-excerpt pb-5")
                data["summary"].append(summary.text.strip() if summary else None)

                img = new_soup.find("a", class_="glightbox")
                data["images"].append(img.get("href") if img else None)

                category = new_soup.find("span", class_="nx-single-category-title")
                data["category"].append(category.text.strip() if category else None)

                mainText = new_soup.find("div", class_="entry-content").findAll(["p", "ul", "ol", "h2", "h3", "h4"])
                data["maintext"].append(" ".join([mt.text.strip() for mt in mainText]))

                tags = new_soup.find("span", class_="tags-links")
                data["tags"].append([tag.text.strip() for tag in tags] if tags else [])

        # Convert data to DataFrame
        df = pd.DataFrame(data)

        # Store data into MongoDB
        for idx, row in df.iterrows():
            news_item = {
                "title": row["title"],
                "date": row["date"],
                "category": row["category"],
                "url": row["url"],
                "images": row["images"],
                "summary": row["summary"],
                "maintext": row["maintext"],
                "tags": row["tags"],
                "link":"https://www.kathimerini.gr"
            }
            if not mongo.db.news.find_one({"title": news_item["title"]}):
                mongo.db.news.insert_one(news_item)

        return jsonify({"message": "Data scraped and stored in MongoDB"}), 200

    except Exception as e:
        logging.error(f"Error during scraping from Kathimerini: {e}")
        return jsonify({"error": "An error occurred during scraping"}), 500


# http://localhost:5000/news_kathimerini?date=2024-06-18&category=Politics
@app.route('/news_kathimerini', methods=['GET'])
def get_news_kathimerini():
    try:
        # Get date and category from query parameters
        date = request.args.get('date')
        category = request.args.get('category')
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))

        # Build the query filter
        query_filter = {}
        if date:
            query_filter["date"] = date
        if category:
            query_filter["category"] = category

        # Query the database with filter and sort by date in descending order
        news_data = mongo.db.news.find(query_filter).sort("date", -1).skip((page - 1) * limit).limit(limit)

        output = []
        for news in news_data:
            output.append({
                "title": news["title"],
                "date": news["date"],
                "category": news["category"],
                "url": news["url"],
                "images": news["images"],
                "summary": news["summary"],
                "maintext": news["maintext"],
                "tags": news["tags"]
            })
        return jsonify(output), 200

    except Exception as e:
        logging.error(f"Error fetching Kathimerini news: {e}")
        return jsonify({"error": "An error occurred while fetching Kathimerini news"}), 500


# http://localhost:5000/news_kathimerini
# body: {
#     "title": "New Article",
#     "date": "2024-06-18",
#     "category": "Technology",
#     "url": "https://example.com/new-article",
#     "images": "https://example.com/image.jpg",
#     "summary": "This is a summary of the new article.",
#     "maintext": "This is the main text of the new article.",
#     "tags": ["tag1", "tag2"]
# }
@app.route('/news_kathimerini', methods=['POST'])
def create_news_kathimerini():
    try:
        news_data = request.get_json()
        if not news_data:
            return jsonify({"error": "No data provided"}), 400
        # Basic validation
        required_fields = ["title", "date", "category", "url", "images", "summary", "maintext", "tags"]
        if not all(field in news_data for field in required_fields):
            return jsonify({"error": "Missing required fields"}), 400

        mongo.db.news.insert_one(news_data)
        return jsonify({"message": "News item created successfully"}), 201

    except Exception as e:
        logging.error(f"Error creating Kathimerini news: {e}")
        return jsonify({"error": "An error occurred while creating Kathimerini news"}), 500


# http://localhost:5000/news_kathimerini/news_id
# body: {
#     "title": "Updated Article",
#     "date": "2024-06-19",
#     "category": "Politics",
#     "url": "https://example.com/updated-article",
#     "images": "https://example.com/updated-image.jpg",
#     "summary": "This is an updated summary of the article.",
#     "maintext": "This is the updated main text of the article.",
#     "tags": ["updated_tag1", "updated_tag2"]
# }
@app.route('/news_kathimerini/<news_id>', methods=['PUT'])
def update_news_kathimerini(news_id):
    try:
        news_data = request.get_json()
        if not news_data:
            return jsonify({"error": "No data provided"}), 400

        mongo.db.news.update_one({'_id': ObjectId(news_id)}, {'$set': news_data})
        return jsonify({"message": "Kathimerini news item updated successfully"}), 200

    except Exception as e:
        logging.error(f"Error updating Kathimerini news: {e}")
        return jsonify({"error": "An error occurred while updating Kathimerini news"}), 500


# http://localhost:5000/news_kathimerini/news_id
@app.route('/news_kathimerini/<news_id>', methods=['DELETE'])
def delete_news_kathimerini(news_id):
    try:
        mongo.db.news.delete_one({'_id': ObjectId(news_id)})
        return jsonify({"message": "Kathimerini news item deleted successfully"}), 200

    except Exception as e:
        logging.error(f"Error deleting Kathimerini news: {e}")
        return jsonify({"error": "An error occurred while deleting Kathimerini news"}), 500


if __name__ == '__main__':
    app.run(debug=True)