import { deleteApi, getApi, postApi, putApi } from "./Axios";

const getAllNewsAPI = () => {
    const response = getApi(`/news`);
    return response;
};

const ScrapeNews1API = () => {
    const response = getApi(`/scrape?start=1&end=2`);
    return response;
};

const ScrapeNews2API = () => {
    const response = getApi(`/scrape_kathimerini?start=1&end=2`);
    return response;
};

const deleteNewsAPI = (id) => {
    const response = deleteApi(`/news/${id}`);
    return response;
};

const addNewsAPI = (data) => {
    const response = postApi(`/news`, data);
    return response;
};

const updateNewsAPI = (id, data) => {
    const response = putApi(`/news/${id}`, data);
    return response;
};



export {
    getAllNewsAPI,
    deleteNewsAPI,
    addNewsAPI,
    updateNewsAPI,
    ScrapeNews1API,
    ScrapeNews2API
};
