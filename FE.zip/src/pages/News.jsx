import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { getAllNewsAPI } from '../service/News';
import Navbar from '../components/Navbar';
import Sidebar from '../components/Sidebar';
import CardList from '../components/CardList';
import { useLocation } from 'react-router-dom';

const News = () => {
  const location = useLocation()
  console.log(location)


  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState({ date: '', category: '' });
  const [data, setData] = useState([location.state]);
  const [isLoading, setIsLoading] = useState(false)

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleFilterChange = (e) => {
    setFilter({ ...filter, [e.target.name]: e.target.value });
  };

  const filteredData = data?.length > 0 ? data
    .filter(item => item.maintext.includes(searchTerm))
    .filter(item => !filter.date || item.date === filter.date)
    .filter(item => !filter.category || item.category === filter.category)
    : []

  return (
    <div className="container-fluid">
      <Navbar searchTerm={searchTerm} onSearch={handleSearch} />
      <div className="row">
        <Sidebar filter={filter} onFilterChange={handleFilterChange} />
        <div className="col-lg-9 col-md-9 col-xs-9 col-xs-12">
          {isLoading && <h1>Loading...</h1>}
          <CardList truncate={false} data={filteredData} />
        </div>
      </div>
    </div>
  );
}

export default News




