import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Modal } from "react-bootstrap";
import { toast } from 'react-toastify';
import { ScrapeNews1API, ScrapeNews2API, addNewsAPI, deleteNewsAPI, getAllNewsAPI, updateNewsAPI } from '../service/News';

const convertToDateTimeLocal = (dateString) => {
    const [datePart, timePart] = dateString.split(' - ');
    const [day, month, year] = datePart.split('/');
    return `${year}-${month}-${day}T${timePart}`;
};

const Dashboard = () => {
    const [data, setData] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [modalIsOpen, setModalIsOpen] = useState(false);
    const [selectedItem, setSelectedItem] = useState(null);
    const [formData, setFormData] = useState({
        _id: '',
        category: '',
        date: '',
        summary: '',
        tags: '',
        title: '',
        url: '',
        images: '',
        maintext: '',
        link: ''
    });

    const navigate = useNavigate();

    useEffect(() => {
        const token = localStorage.getItem('token');
        if (!token) {
            toast.error('Token required');
            navigate('/');
        } else {
            fetchingDataFromApi();
        }
    }, []);

    const fetchingDataFromApi = async () => {
        try {
            setIsLoading(true)
            const res = await getAllNewsAPI()
            setIsLoading(false)
            if (res.success) {
                setData(res.data)
            } else {
                setData([])
            }
        } catch (error) {
            setIsLoading(false)
            setData([])
            toast.error(error?.message || error?.msg)
        }
    }

    const handleEdit = (item) => {
        setSelectedItem(item);
        setFormData({
            _id: item._id,
            category: item.category,
            date: convertToDateTimeLocal(item.date),
            summary: item.summary,
            // tags: item.tags.join(', '),
            tags: item.tags,
            title: item.title,
            url: item.url,
            images: item.images,
            maintext: item.maintext,
            link: item.link,
        });
        setModalIsOpen(true);
    };

    const handleDelete = async (id) => {
        try {
            setIsLoading(true)
            const res = await deleteNewsAPI(id)
            setIsLoading(false)
            toast.success("News deleted successfully!")
        } catch (error) {
            setIsLoading(false)
            toast.error(error?.message || error?.msg)
        }
    };

    const handleSave = async () => {

        let updatedData = JSON.parse(JSON.stringify(formData));
        delete updatedData._id
        try {
            setIsLoading(true)
            if (formData._id) {
                const res = await updateNewsAPI(formData._id, updatedData)
                toast.success("News updated successfully!")
            } else {
                const res = await addNewsAPI(updatedData)
                toast.success("News added successfully!")
            }
            setIsLoading(false)
        } catch (error) {
            setIsLoading(false)
            toast.error(error?.message || error?.msg)
        }


        fetchingDataFromApi()
        setModalIsOpen(false);

    };
    const handleScrape1 = async () => {
        try {
            setIsLoading(true)
            const res = await ScrapeNews1API()
            toast.success("Data Scrapped successfully!")
            setIsLoading(false)
        } catch (error) {
            setIsLoading(false)
            toast.error(error?.message || error?.msg)
        }
        fetchingDataFromApi()
    };
    const handleScrape2 = async () => {
        try {
            setIsLoading(true)
            const res = await ScrapeNews2API()
            toast.success("Data Scrapped successfully!")
            setIsLoading(false)
        } catch (error) {
            setIsLoading(false)
            toast.error(error?.message || error?.msg)
        }
        fetchingDataFromApi()
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleAdd = () => {
        setSelectedItem(null);
        setFormData({
            _id: '',
            category: '',
            date: '',
            summary: '',
            tags: '',
            title: '',
            url: '',
            images: '',
            maintext: '',
            link: ""
        });
        setModalIsOpen(true);
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        navigate('/');
    }

    return (
        <div className="container mt-5">
            <div className='d-flex justify-content-end'>
                <button onClick={handleLogout} className='btn btn-danger'>
                    Logout
                </button>
            </div>
            <h1>Dashboard</h1>
            <div className='d-flex justify-content-end'>
                <button onClick={handleScrape1} className='btn btn-info'>
                    Scrape Data From naftemporiki
                </button>
                &nbsp;
                <button onClick={handleScrape2} className='btn btn-info'>
                    Scrape Data From kathimerini
                </button>
            </div>
            <button className="btn btn-primary mb-3" onClick={handleAdd}>Add Data</button>
            {isLoading ? (
                <p>Loading...</p>
            ) : (
                <table className="table table-striped mt-3">
                    <thead>
                        <tr>
                            <th>Category</th>
                            <th>Date</th>
                            <th>Summary</th>
                            <th>Tags</th>
                            <th>Title</th>
                            <th>URL</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map(item => (
                            <tr key={item._id}>
                                <td>{item.category}</td>
                                <td>{item.date}</td>
                                <td>{item.summary}</td>
                                {/* <td>{item.tags.join(', ')}</td> */}
                                <td>{item.tags}</td>
                                <td>{item.tags}</td>
                                <td>{item.title}</td>
                                <td><a href={item.url} target="_blank" rel="noopener noreferrer">Link</a></td>
                                <td>
                                    <div className='d-flex'>
                                        <button className="btn btn-sm btn-warning me-2" onClick={() => handleEdit(item)}>Edit</button>
                                        <button className="btn btn-sm btn-danger" onClick={() => handleDelete(item._id)}>Delete</button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            <Modal
                show={modalIsOpen}
                size='lg'
                onHide={() => setModalIsOpen(false)}
            >
                <Modal.Header closeButton>
                    <Modal.Title>
                        <span style={{ color: "black" }}>{selectedItem ? 'Edit Data' : 'Add Data'}</span>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body >

                    <form>
                        <div className="mb-3">
                            <label htmlFor="category" className="form-label">Category</label>
                            <input
                                type="text"
                                className="form-control"
                                id="category"
                                name="category"
                                value={formData.category}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="date" className="form-label">Date</label>
                            <input
                                type="datetime-local"
                                className="form-control"
                                id="date"
                                name="date"
                                value={formData.date}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="summary" className="form-label">Summary</label>
                            <input
                                type="text"
                                className="form-control"
                                id="summary"
                                name="summary"
                                value={formData.summary}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="tags" className="form-label">Tags</label>
                            <input
                                type="text"
                                className="form-control"
                                id="tags"
                                name="tags"
                                value={formData.tags}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="title" className="form-label">Title</label>
                            <input
                                type="text"
                                className="form-control"
                                id="title"
                                name="title"
                                value={formData.title}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="url" className="form-label">URL</label>
                            <input
                                type="text"
                                className="form-control"
                                id="url"
                                name="url"
                                value={formData.url}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="images" className="form-label">Image Link</label>
                            <input
                                type="text"
                                className="form-control"
                                id="images"
                                name="images"
                                value={formData.images}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="maintext" className="form-label">Main Text</label>
                            <input
                                type="text"
                                className="form-control"
                                id="maintext"
                                name="maintext"
                                value={formData.maintext}
                                onChange={handleChange}
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="link" className="form-label">Website Link</label>
                            <input
                                type="text"
                                className="form-control"
                                id="link"
                                name="link"
                                value={formData.link}
                                onChange={handleChange}
                            />
                        </div>
                    </form>

                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" onClick={() => setModalIsOpen(false)}>Close</button>
                        <button type="button" className="btn btn-primary" onClick={handleSave}>Save Changes</button>
                    </div>
                </Modal.Body>

            </Modal>
        </div>
    );
};

export default Dashboard;
