import React from 'react';
import { useNavigate } from 'react-router-dom';

const Navbar = ({ searchTerm, onSearch }) => {
    const navigate = useNavigate()
    const handleNavigate = () => {
        navigate('/login')
    }
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container-fluid">
        <div className="d-flex">
          <button onClick={handleNavigate} className="btn btn-outline-primary me-2">Login</button>
        </div>
        <form className="d-flex mx-auto">
          <input 
            className="form-control me-2" 
            type="search" 
            placeholder="Search" 
            aria-label="Search" 
            value={searchTerm}
            onChange={onSearch}
          />
        </form>
      </div>
    </nav>
  );
};

export default Navbar;
