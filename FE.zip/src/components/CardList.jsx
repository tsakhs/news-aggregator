import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
        return text.substring(0, maxLength) + '...';
    }
    return text;
};

const CardList = ({ data, className = "", truncate }) => {
    const navigate = useNavigate()
    const handleFull = (item) => {
        navigate(`/news/${item._id}`, { state: item })
    }
    return (
        <div className="row p-3">
            {data.map(item => (
                <div onClick={() => handleFull(item)} key={item._id} className={className}>
                    <div className="card">
                        <img src={item.images} className="card-img-top" alt={item.maintext} />
                        <div className="card-body">
                            {item?.link && <Link onClick={(e) => e.stopPropagation()} to={item?.link || '#'}>{item.link}</Link>}
                            <p className="d-flex justify-content-end">{item.date}</p>

                            <p className="card-text">{truncate ? truncateText(item.maintext, 500) : item.maintext}</p>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default CardList;
