import React from 'react';

const Sidebar = ({ filter, onFilterChange }) => {
  return (
    <div className="col-lg-3 col-md-3 col-xs-3 col-xs-12 p-3 border-right">
      <form>
        <div className="mb-3">
          <label htmlFor="date" className="form-label">Date</label>
          <input
            type="date"
            className="form-control"
            id="date"
            name="date"
            value={filter.date}
            onChange={onFilterChange}
          />
        </div>
        <div className="mb-3">
          <label htmlFor="category" className="form-label">Category</label>
          <input
            type="text"
            className="form-control"
            id="category"
            name="category"
            value={filter.category}
            onChange={onFilterChange}
          />
        </div>
      </form>
    </div>
  );
};

export default Sidebar;
