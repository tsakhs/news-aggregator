import './App.css'
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import HomePage from './pages/HomePage';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import News from './pages/News';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

function App() {

  const router = createBrowserRouter([
    {
      path: "/",
      element: <HomePage />,
    },
    {
      path: "/news/:id",
      element: <News />,
    },
    {
      path: "/login",
      element: <Login />,
    },
    {
      path: "/dashboard",
      element: <Dashboard />,
    },
  ]);


  return (
    <>
      <RouterProvider router={router} />
      <ToastContainer />

    </>
  )
}

export default App
